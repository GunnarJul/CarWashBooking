﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarWashBooking.Constants
{
    public static class SessionConstants
    {
        public const string SessionActiceUserID = "SessionActiveUserID";
        public const string SessionActiceUser = "SessionActiveUser";
    }
}
